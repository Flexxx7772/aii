import { useState, useRef, useEffect, useCallback } from 'react';
import { Sparkles, Trash2, Key, ChevronDown } from 'lucide-react';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import TypingIndicator from './components/TypingIndicator';
import ApiKeyModal from './components/ApiKeyModal';
import { Message } from './types/chat';
import { EDGE_FUNCTION_URL } from './lib/supabase';

const STORAGE_KEY = 'gemini_api_key';
const HISTORY_KEY = 'gemini_chat_history';

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>(() => {
    try {
      const saved = localStorage.getItem(HISTORY_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as Array<Omit<Message, 'timestamp'> & { timestamp: string }>;
        return parsed.map((m) => ({ ...m, timestamp: new Date(m.timestamp) }));
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [isLoading, setIsLoading] = useState(false);
  const [apiKey, setApiKey] = useState<string>(() => localStorage.getItem(STORAGE_KEY) ?? '');
  const [showApiModal, setShowApiModal] = useState(false);
  const [showScrollDown, setShowScrollDown] = useState(false);
  const [newMessageId, setNewMessageId] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Persist chat history
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(messages));
    }
  }, [messages]);

  // Show scroll-down button when not at bottom
  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setShowScrollDown(distanceFromBottom > 120);
  };

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const handleSaveApiKey = (key: string) => {
    setApiKey(key);
    localStorage.setItem(STORAGE_KEY, key);
    setShowApiModal(false);
  };

  const handleClearChat = () => {
    setMessages([]);
    localStorage.removeItem(HISTORY_KEY);
  };

  const handleSend = async (text: string, imageFile?: File) => {
    if (!apiKey) {
      setShowApiModal(true);
      return;
    }

    const userMsgId = crypto.randomUUID();
    const userParts: Message['parts'] = [];
    let imagePreview: string | undefined;

    if (imageFile) {
      const base64 = await fileToBase64(imageFile);
      userParts.push({ inlineData: { mimeType: imageFile.type, data: base64 } });
      imagePreview = URL.createObjectURL(imageFile);
    }
    if (text) {
      userParts.push({ text });
    }

    const userMessage: Message = {
      id: userMsgId,
      role: 'user',
      parts: userParts,
      timestamp: new Date(),
      imagePreview,
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setNewMessageId(userMsgId);
    setIsLoading(true);
    setTimeout(scrollToBottom, 100);

    try {
      const response = await fetch(EDGE_FUNCTION_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'X-Gemini-Key': apiKey,
        },
        body: JSON.stringify({
          messages: updatedMessages.map((m) => ({
            role: m.role,
            parts: m.parts,
          })),
          apiKey,
        }),
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error ?? 'Gagal mendapatkan respons dari Gemini.');
      }

      const assistantMsgId = crypto.randomUUID();
      const assistantMessage: Message = {
        id: assistantMsgId,
        role: 'assistant',
        parts: [{ text: data.text }],
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      setNewMessageId(assistantMsgId);
      setTimeout(scrollToBottom, 100);
    } catch (err) {
      const errId = crypto.randomUUID();
      setMessages((prev) => [
        ...prev,
        {
          id: errId,
          role: 'assistant',
          parts: [{ text: `Oops! Terjadi kesalahan: ${(err as Error).message}. Pastikan API key kamu valid.` }],
          timestamp: new Date(),
        },
      ]);
      setNewMessageId(errId);
    } finally {
      setIsLoading(false);
    }
  };

  const hasMessages = messages.length > 0;

  return (
    <div className="flex flex-col h-screen bg-gray-950 text-gray-100 overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 flex items-center justify-between px-4 py-3.5 border-b border-white/5 bg-gray-950/80 backdrop-blur-xl z-10 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="relative w-9 h-9">
            <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-400 blur-sm opacity-60 animate-pulse" />
            <div className="relative w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg">
              <Sparkles size={18} className="text-white" />
            </div>
          </div>
          <div>
            <h1 className="font-bold text-white text-base leading-none">Gemini AI Chat</h1>
            <p className="text-emerald-400 text-xs mt-0.5 font-medium">
              {isLoading ? (
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  Sedang berpikir...
                </span>
              ) : (
                'Powered by Google Gemini 1.5 Flash'
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasMessages && (
            <button
              onClick={handleClearChat}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all border border-white/5 hover:border-red-500/20"
              title="Hapus semua chat"
            >
              <Trash2 size={13} />
              <span className="hidden sm:inline">Hapus</span>
            </button>
          )}
          <button
            onClick={() => setShowApiModal(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg transition-all border ${
              apiKey
                ? 'text-emerald-400 border-emerald-500/20 bg-emerald-500/10 hover:bg-emerald-500/20'
                : 'text-yellow-400 border-yellow-500/20 bg-yellow-500/10 hover:bg-yellow-500/20 animate-pulse'
            }`}
          >
            <Key size={13} />
            <span>{apiKey ? 'API Key ✓' : 'Set API Key'}</span>
          </button>
        </div>
      </header>

      {/* Chat area */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-4 py-6 space-y-5 scroll-smooth"
      >
        {!hasMessages ? (
          /* Empty state */
          <div className="flex flex-col items-center justify-center h-full text-center gap-6 py-12">
            <div className="relative">
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-400 blur-2xl opacity-20 scale-110" />
              <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-400 flex items-center justify-center shadow-2xl shadow-emerald-900/40">
                <Sparkles size={40} className="text-white" />
              </div>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Halo! Aku Gemini AI</h2>
              <p className="text-gray-400 text-sm max-w-sm leading-relaxed">
                Tanya apa aja, atau upload gambar untuk aku analisis. Aku siap bantu kamu!
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-sm mt-2">
              {[
                { icon: '💡', text: 'Jelaskan konsep machine learning' },
                { icon: '🖼️', text: 'Analisis gambar yang aku upload' },
                { icon: '✍️', text: 'Bantu tulis email profesional' },
                { icon: '🔍', text: 'Review dan perbaiki kode ini' },
              ].map((s) => (
                <button
                  key={s.text}
                  onClick={() => {
                    if (!apiKey) { setShowApiModal(true); return; }
                    handleSend(s.text);
                  }}
                  className="flex items-center gap-2 px-4 py-3 bg-gray-800/60 hover:bg-gray-800 border border-white/5 hover:border-emerald-500/30 rounded-xl text-left text-sm text-gray-300 hover:text-white transition-all group"
                >
                  <span className="text-base">{s.icon}</span>
                  <span className="group-hover:text-emerald-300 transition-colors">{s.text}</span>
                </button>
              ))}
            </div>
            {!apiKey && (
              <p className="text-yellow-400/80 text-xs mt-2 bg-yellow-500/10 border border-yellow-500/20 rounded-xl px-4 py-2.5">
                Set API Key dulu ya bro sebelum mulai chat!
              </p>
            )}
          </div>
        ) : (
          messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} isNew={msg.id === newMessageId} />
          ))
        )}

        {isLoading && <TypingIndicator />}
        <div ref={bottomRef} />
      </div>

      {/* Scroll to bottom button */}
      {showScrollDown && (
        <button
          onClick={scrollToBottom}
          className="fixed bottom-24 right-6 w-9 h-9 rounded-full bg-gray-800 border border-white/10 flex items-center justify-center shadow-lg hover:bg-gray-700 transition-all z-20 scroll-btn-appear"
        >
          <ChevronDown size={16} className="text-gray-300" />
        </button>
      )}

      {/* Input */}
      <ChatInput onSend={handleSend} disabled={isLoading} />

      {/* API Key modal */}
      {showApiModal && (
        <ApiKeyModal onSave={handleSaveApiKey} onClose={() => setShowApiModal(false)} />
      )}
    </div>
  );
}
