import { useState } from 'react';
import { Key, X, ExternalLink } from 'lucide-react';

interface Props {
  onSave: (key: string) => void;
  onClose: () => void;
}

export default function ApiKeyModal({ onSave, onClose }: Props) {
  const [key, setKey] = useState('');

  const handleSave = () => {
    if (key.trim()) {
      onSave(key.trim());
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-gray-900 border border-white/10 rounded-2xl shadow-2xl w-full max-w-md p-6 modal-appear">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-500 to-orange-400 flex items-center justify-center">
              <Key size={18} className="text-white" />
            </div>
            <div>
              <h2 className="text-white font-semibold">Gemini API Key</h2>
              <p className="text-gray-400 text-xs">Diperlukan untuk menggunakan AI</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-300 transition-colors">
            <X size={20} />
          </button>
        </div>

        <p className="text-gray-400 text-sm mb-4 leading-relaxed">
          Masukkan Gemini API key kamu. Key ini disimpan di browser kamu aja (tidak dikirim ke server kami).
        </p>

        <a
          href="https://aistudio.google.com/app/apikey"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-xs text-emerald-400 hover:text-emerald-300 mb-4 transition-colors"
        >
          <ExternalLink size={12} />
          Dapatkan API key gratis di Google AI Studio
        </a>

        <input
          type="password"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSave()}
          placeholder="AIza..."
          className="w-full bg-gray-800 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-emerald-500 transition-colors mb-4"
          autoFocus
        />

        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2.5 rounded-xl border border-white/10 text-gray-400 hover:text-gray-200 hover:border-white/20 text-sm font-medium transition-all"
          >
            Batal
          </button>
          <button
            onClick={handleSave}
            disabled={!key.trim()}
            className="flex-1 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-sm font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-emerald-900/30"
          >
            Simpan & Mulai
          </button>
        </div>
      </div>
    </div>
  );
}
