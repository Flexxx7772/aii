import { useEffect, useRef } from 'react';
import { Bot, User } from 'lucide-react';
import { Message } from '../types/chat';

interface Props {
  message: Message;
  isNew?: boolean;
}

function formatText(text: string): string {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`(.*?)`/g, '<code class="bg-gray-800 px-1 py-0.5 rounded text-emerald-400 text-sm font-mono">$1</code>')
    .replace(/\n/g, '<br/>');
}

export default function ChatMessage({ message, isNew }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const isUser = message.role === 'user';
  const textPart = message.parts.find((p) => p.text)?.text ?? '';
  const imagePart = message.parts.find((p) => p.inlineData);

  useEffect(() => {
    if (isNew && ref.current) {
      ref.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, [isNew]);

  return (
    <div
      ref={ref}
      className={`flex gap-3 w-full ${isUser ? 'flex-row-reverse' : 'flex-row'} message-appear`}
    >
      {/* Avatar */}
      <div
        className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center shadow-lg ${
          isUser
            ? 'bg-gradient-to-br from-blue-500 to-cyan-400'
            : 'bg-gradient-to-br from-emerald-500 to-teal-400'
        }`}
      >
        {isUser ? <User size={16} className="text-white" /> : <Bot size={16} className="text-white" />}
      </div>

      {/* Bubble */}
      <div className={`flex flex-col gap-2 max-w-[75%] ${isUser ? 'items-end' : 'items-start'}`}>
        {/* Image preview */}
        {(message.imagePreview || imagePart) && (
          <div className="rounded-2xl overflow-hidden border border-white/10 shadow-xl">
            <img
              src={message.imagePreview ?? `data:${imagePart?.inlineData?.mimeType};base64,${imagePart?.inlineData?.data}`}
              alt="uploaded"
              className="max-w-xs max-h-60 object-cover"
            />
          </div>
        )}

        {/* Text */}
        {textPart && (
          <div
            className={`px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-lg ${
              isUser
                ? 'bg-gradient-to-br from-blue-600 to-cyan-600 text-white rounded-tr-sm'
                : 'bg-gray-800 text-gray-100 rounded-tl-sm border border-white/5'
            }`}
            dangerouslySetInnerHTML={{ __html: formatText(textPart) }}
          />
        )}

        {/* Timestamp */}
        <span className="text-xs text-gray-600 px-1">
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
}
