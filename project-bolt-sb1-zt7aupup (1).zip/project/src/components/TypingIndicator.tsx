import { Bot } from 'lucide-react';

export default function TypingIndicator() {
  return (
    <div className="flex gap-3 message-appear">
      <div className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-teal-400 shadow-lg">
        <Bot size={16} className="text-white" />
      </div>
      <div className="bg-gray-800 border border-white/5 px-4 py-3 rounded-2xl rounded-tl-sm shadow-lg flex items-center gap-1.5">
        <span className="w-2 h-2 bg-emerald-400 rounded-full typing-dot" style={{ animationDelay: '0ms' }} />
        <span className="w-2 h-2 bg-emerald-400 rounded-full typing-dot" style={{ animationDelay: '150ms' }} />
        <span className="w-2 h-2 bg-emerald-400 rounded-full typing-dot" style={{ animationDelay: '300ms' }} />
      </div>
    </div>
  );
}
