import { useRef, useState, KeyboardEvent } from 'react';
import { Send, ImagePlus, X } from 'lucide-react';

interface Props {
  onSend: (text: string, imageFile?: File) => void;
  disabled?: boolean;
}

export default function ChatInput({ onSend, disabled }: Props) {
  const [text, setText] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setImagePreview(ev.target?.result as string);
    reader.readAsDataURL(file);
    if (fileRef.current) fileRef.current.value = '';
  };

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const handleSend = () => {
    if ((!text.trim() && !imageFile) || disabled) return;
    onSend(text.trim(), imageFile ?? undefined);
    setText('');
    clearImage();
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 160)}px`;
  };

  const canSend = (text.trim() || imageFile) && !disabled;

  return (
    <div className="p-4 border-t border-white/5">
      {/* Image preview strip */}
      {imagePreview && (
        <div className="mb-3 flex items-start gap-2 image-preview-appear">
          <div className="relative rounded-xl overflow-hidden border border-white/10 shadow-lg">
            <img src={imagePreview} alt="preview" className="h-20 w-20 object-cover" />
            <button
              onClick={clearImage}
              className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/70 flex items-center justify-center hover:bg-red-600 transition-colors"
            >
              <X size={10} className="text-white" />
            </button>
          </div>
          <span className="text-xs text-gray-500 mt-1">{imageFile?.name}</span>
        </div>
      )}

      <div className="flex items-end gap-2 bg-gray-800 border border-white/10 rounded-2xl px-3 py-2.5 focus-within:border-emerald-500/50 transition-colors shadow-lg">
        {/* Image button */}
        <button
          onClick={() => fileRef.current?.click()}
          disabled={disabled}
          className="flex-shrink-0 w-8 h-8 flex items-center justify-center text-gray-500 hover:text-emerald-400 disabled:opacity-40 transition-colors rounded-lg hover:bg-white/5"
          title="Upload gambar"
        >
          <ImagePlus size={18} />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          onChange={handleImage}
          className="hidden"
        />

        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          placeholder="Ketik pesan atau upload gambar... (Enter untuk kirim)"
          rows={1}
          className="flex-1 bg-transparent text-gray-100 placeholder-gray-500 text-sm resize-none focus:outline-none leading-relaxed py-0.5 disabled:opacity-50"
          style={{ minHeight: '24px', maxHeight: '160px' }}
        />

        {/* Send button */}
        <button
          onClick={handleSend}
          disabled={!canSend}
          className={`flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-xl transition-all shadow-lg ${
            canSend
              ? 'bg-gradient-to-br from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white scale-100 hover:scale-105 active:scale-95 send-pulse'
              : 'bg-gray-700 text-gray-500 cursor-not-allowed'
          }`}
          title="Kirim pesan"
        >
          <Send size={14} className={canSend ? 'translate-x-px' : ''} />
        </button>
      </div>
      <p className="text-center text-xs text-gray-700 mt-2">
        AI bisa membuat kesalahan. Verifikasi informasi penting.
      </p>
    </div>
  );
}
